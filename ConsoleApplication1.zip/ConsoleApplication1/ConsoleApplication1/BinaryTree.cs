﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class BinaryTree
    {
        private BNode root;
        private int count;
        public BinaryTree()
        {
            root = null;
            count = 0;
        }
        public bool IsEmpty()
        {
            return root == null;
        }
        public void insert(int d)
        {
            if (IsEmpty())
            {
                root = new BNode(d);
            }
            else
            {
                root.InsertData(root, d);
            }

            count++;
        }

        public bool Search(int s)
        {
            return root.Search(root, s);
        }

        public bool isLeaf()
        {
            if (!IsEmpty())
                return root.IsLeaf(root);

            return true;
        }

        public void display()
        {
            if (!IsEmpty())
                root.display(root);
        }

        public int Count()
        {
            return count;
        }
    }
    public class BNode
    {
        private int data;
        private BNode next;
        private BNode prev;
        public BNode(int val)
        {
            data = val;
            next = null;
            prev = null;
        }
        public bool IsLeaf(BNode node)
        {
            return (node.next == null && node.prev == null);
        }
        public void InsertData(BNode node, int val)
        {
            if(node == null)
            {
                node = new BNode(val);
            }
            else if(node.data < val)
            {
                 InsertData(node.next, val);

            }
            else if(node.data > val)
            {
                 InsertData(node.prev, val);
            }

        }
        public bool Search(BNode node, int s)
        {
            if (node == null)
                return false;
            if(node.data == s)
            {
                return true;
            }
            else if(node.data < s)
            {
                return Search(node.next, s);
            }
            else if(node.data >s)
            {
                return Search(node.prev, s);
            }
            return false;
        }
        public void display(BNode n)
        {
            if (n == null)
                return;

            display(n.prev);
            Console.Write(" " + n.data);
            display(n.next);
        }
    }
}
