﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApplication1
{
    public class practice
    {
        public int findMissingNum(int[] nums)
        {
            int missing = 0;
            int exTotal = nums.Count() * (nums.Count() + 1) / 2;
            for (var i = 0; i < nums.Count(); i++)
            {
                missing += nums[i];
            }
            return exTotal - missing;
        }
    }
}
