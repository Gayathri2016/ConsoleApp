﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Node
    {
        public int data;
        public Node next;        
        public Node(int i)
        {
            data = i;
            next = null;
        }
        public void Print()
        {
            Console.Write( data + "->");
            if(next != null)
            {
                next.Print();
            }
        }
        public void AddToEnd(int data)
        {
            if(next == null)
            {
                next = new Node(data);
            }
            else
            {
                next.AddToEnd(data);
            }
        }
        public void AddSorted(int data)
        {
            if (next == null)
            {
                next = new Node(data);
            }
            else if (data < next.data)
            {
                Node temp = new Node(data);
                temp.next = this.next;
                this.next = temp;
            }
            else
            {
                next.AddSorted(data);
            }
        }
        public void Traverse()
        {
            var temp = new MyList();
            while(this.next!=null)
            {
                
            }
        }
    }
    public class MyList
    {
        public Node headNode;
        public MyList()
        {
            headNode = null;
        }
        public void AddToEnd(int data)
        {
            if(headNode == null)
            {
                headNode = new Node(data);
            }
            else
            {
                headNode.AddToEnd(data);
            }
        }
        public void Print()
        {
            if(headNode !=null)
            {
                headNode.Print();
            }
        }
        public void AddToBegining(int data)
        {
            if (headNode == null)
            {
                headNode = new Node(data);
            }
            else
            {
                Node temp = new Node(data);
                temp.next = headNode;
                headNode = temp;
            }
        }
        public void Remove(int data)
        {
            if(headNode ==null)
            {
                headNode = new Node(data);
            }
            else if(data == headNode.data)
            {
                Node temp = new Node(data);
                temp = headNode.next;
                headNode = temp;

            }
        }
        public void AddTwoNumbers(int l1, int l2)
        {
            Node temp = new Node(l1 + l2);                
            headNode = temp;
           
        }
        public void AddSorted(int data)
        {
            if(headNode == null)
            {
                headNode = new Node(data);
            }
            else if(data < headNode.data)
            {
                AddToBegining(data);
            }
            else
            {
                headNode.AddSorted(data);
            }
        }
      
    }
    
}
