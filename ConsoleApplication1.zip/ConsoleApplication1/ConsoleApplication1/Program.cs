﻿using System;
using LinkedList = System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using LumenWorks.Framework.IO.Csv;
using System.IO;
using System.Numerics;


namespace ConsoleApplication1
{
    class Program
    {
        delegate void Printer();
        static void Main(string[] args)
        {
            /* var line = Console.ReadLine();

             var nums = line.Split(' ');


             List<string> ls = new List<string>();

             for (var j = nums.Length - 1; j > 0; j--)
             {

                 Console.WriteLine(string.Join("\n", nums[j]));
             }

             //Console.WriteLine(ls.ToArray().ToString());
             */

            Console.Write(bigIntMultiplication(BigInteger.Parse("3141592653589793238462643383279502884197169399375105820974944592"), BigInteger.Parse("2718281828459045235360287471352662497757247093699959574966967627")));
             var p = new practice();
            BinaryTree b = new BinaryTree();

            b.insert(1);
            b.insert(6);
            b.insert(2);
            b.insert(4);
            b.insert(5);
            b.insert(3);

            b.display();

          //  Console.ReadLine();
            int[] array1 = {  1, 2, 4, 5, 6 };
            Console.WriteLine(p.findMissingNum(array1));

            Console.WriteLine(FindDuplicates(array1));
            List<Printer> printers = new List<Printer>();
            int i = 0;
            for (; i < 10; i++)
            {
                printers.Add(delegate { Console.WriteLine(i); });

            }
            foreach (var printer in printers)
            {
                printer();
            }
       /*     PrintTraingle(6,6);
            Console.WriteLine(LengthOfLongestSubstring("dvdf"));
            MyList lnList = new MyList();
            lnList.AddToEnd(2);
            lnList.AddToEnd(4);
            lnList.AddToEnd(3);
            //lnList.Print();
            MyList lnList2 = new MyList();
            lnList2.AddToEnd(5);
            lnList2.AddToEnd(6);
            lnList2.AddToEnd(4);
            //lnList2.Print();
            ListNode l1 = new ListNode(2);
            l1.next = new ListNode(4);
            l1.next = new ListNode(3);
            ListNode l2 = new ListNode(5);
            l2.next = new ListNode(6);
            l2.next = new ListNode(4);

            Console.WriteLine(AddTwoNumbers(l1, l2));
            //  Console.WriteLine(Solution.BackspaceCompare("a#cc", "b"));

            //  Console.WriteLine(isPrime(17));
            // Console.WriteLine(BinarySearch("xywrrmu#p", "#"));
            //"bxj##tw"        "bxo#j##tw" "a##c"            "#a#c"
            Console.WriteLine(BackspaceCompare("a##c", "#a#c"));

            GetTestLoginData().ToList();
            int[] array = { 1, 2, 4, 5, 6 };//{ 1, 3, 6, 4, 1, 2 };//{ 2, 4, 7, 8 };
            int[] myarray = { 2, 4, 7, 8, 4 };
            int[] nums1 = { 1, 3 };
            int[] nums2 = { 2 };
            FindMedianSortedArrays(nums1, nums2);
            //ListNode l1 = new ListNode(7);
            //l1.next = new ListNode(6);

            //ListNode l2 = new ListNode(4);
            //l2.next = new ListNode(3);

            string[] strArray = { "aca", "cba" };
            Console.WriteLine(GetSmallest(array));
            GetCurrentQuarter();
            Console.WriteLine(string.Join(",", add(array, 10)));
            Console.WriteLine(Reverse(-2147447412));
            Console.WriteLine(countandsay(5));
            //Console.WriteLine(SearchInsert(array, 0));
            Console.WriteLine(LongestCommonPrefix(strArray));
            Console.WriteLine(IsValid("[](])"));
            Console.WriteLine(RemoveDuplicates(myarray));
            Console.WriteLine(RemoveElement(myarray, 1));
            //Console.WriteLine(MergeTwoLists(l1, l2));
            //Console.WriteLine(StrStr("hello", "ll"));*/
        }

        public static BigInteger bigIntMultiplication(BigInteger x, BigInteger y)
        {
            int N =(int)Math.Max(MyBigInteger.BitLength(x), MyBigInteger.BitLength(y));
            if (N <= 10000)
                return x*y;
            N = (N +1)/2;
            BigInteger b = x>>N;
            BigInteger a = x - (b<<N);
            BigInteger d = y >> N;
            BigInteger c = y - (d << N);

            BigInteger ac = bigIntMultiplication(a, c);
            BigInteger bd = bigIntMultiplication(b, d);
            BigInteger abcd = bigIntMultiplication(a + b, c + d);
           
            return ac + ((abcd-ac-bd)<<N)+ (bd<<2*N);

        }
        public static BigInteger myBigIntMultiplication(BigInteger x, BigInteger y)
        {
           // var first = MyBigInteger.BitLength(x);
            //var second = MyBigInteger.BitLength(y);
            int N = (int)Math.Max(MyBigInteger.BitLength(x), MyBigInteger.BitLength(y));
            if (N <= 1)
                return x * y;
            N = (N + 1) / 2;
            BigInteger b = x >> N;
            BigInteger a = x - (b << N);
            BigInteger d = y >> N;
            BigInteger c = y - (d << N);

            BigInteger ac = bigIntMultiplication(a, c);
            BigInteger bd = bigIntMultiplication(b, d);
            BigInteger abcd = bigIntMultiplication(a + b, c + d);

            return ac + ((abcd - ac - bd) << N) + (bd << 2 * N);

        }

        public static Boolean isPrime(int n)
        {
            if (n <= 1) return false;
            if (n == 2) return true;
            if (n % 2 == 0) return false;
            double m = Math.Sqrt(n);

            for (int i = 3; i <= m; i += 2)
                if (n % i == 0)
                    return false;

            return true;
        }
        public static int[] add(int[] nums, int target)
        {


            List<int> values = new List<int>();


            for (int i = 0; i < nums.Length; i++)
            {
                for (int j = i + 1; j < nums.Length; j++)
                {
                    if (target == nums[i] + nums[j])
                    {
                        values.Add(i);
                        values.Add(j);

                    }
                }

            }



            return values.ToArray();
        }
        public static string ReverseStr(string s)
        {
            var result = new StringBuilder();
            for(int i =(s.Length-1); i == 0; i--)
            {

            }
            return string.Empty;
        }
        public static bool Reverse(int num)
        {
            var reverse = 0;
            // var intial_reverse = 0;           
            var n = num < 0 ? num * -1 : num;
            while (n > 0)
            {

                reverse = reverse * 10 + n % 10;

                //if ((reverse - n % 10) / 10 != intial_reverse)
                //{
                //    return false;
                //}
                //intial_reverse = reverse;
                n = n / 10;

            }


            // reverse = num < 0 ? -System.Math.Abs(reverse): reverse;
            if (reverse == num)
                return true;
            else
                return false;
        }
        public static string countandsay(int n)
        {


            string say = string.Empty;
            if (n == 1)
                return "1";
            if (n == 2)
                return "11";

            say = "11";
            if (n > 0)
            {

                for (int i = 3; i <= n; i++)
                {
                    var tmp = string.Empty;
                    say += "$";
                    int cnt = 1;

                    for (int j = 1; j < say.Length; j++)
                    {
                        if (say[j] != say[j - 1])
                        {
                            tmp += cnt;
                            tmp += say[j - 1];
                            cnt = 1;
                        }
                        else
                        {
                            cnt++;
                        }


                    }
                    say = tmp;

                }

            }

            return say;
        }
        public static bool IsValid(string s)
        {
            string[] openParan = { "(", "{", "[" };
            string[] closedParan = { ")", "}", "]" };
            var valid = false;
            Stack<string> strMatch = new Stack<string>();

            for (int i = 0; i < s.Length; i++)
            {

                if (openParan.Contains(s[i].ToString()))
                {
                    strMatch.Push(s[i].ToString());
                }
                if (closedParan.Contains(s[i].ToString()))
                {
                    if (strMatch.Count > 0)
                    {
                        if (!IsValidMatch(strMatch.Pop(), s[i].ToString()))
                        {
                            valid = false;
                            break;
                        }
                        else
                        {
                            valid = true;
                        }
                    }
                    else
                    {
                        valid = false;
                        break;

                    }
                }


            }
            if (strMatch.Count > 0)
            {
                valid = false;
            }

            return valid;

        }
        public static bool IsValidMatch(string ch1, string ch2)
        {

            if (ch1.Equals("(") && ch2.Equals(")"))
            {
                return true;

            }
            else if (ch1.Equals("{") && ch2.Equals("}"))
            {
                return true;

            }
            else if (ch1.Equals("[") && ch2.Equals("]"))
            {
                return true;

            }
            else
            {
                return false;
            }

        }
        public static string LongestCommonPrefix(string[] strs)
        {
            var lp = string.Empty;
            var value = strs.FirstOrDefault();

            if (strs != null && strs.Count() > 1)
            {
                for (int i = 1; i < strs.Length; i++)
                {
                    lp = string.Empty;


                    for (int j = 0; j < strs[i].Length; j++)
                    {

                        if (!value.Equals(string.Empty) && value.Count() > j && strs[i][j] == value[j])

                        {
                            lp += value[j].ToString();
                        }
                        else
                        {
                            break;
                        }


                    }
                    value = lp;

                }

                return lp;
            }
            else if (strs.Length == 0)
            {
                return "";
            }
            else
            {
                return value;
            }


        }
        public static int minString(string[] arr)
        {
            int min = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Length < min)
                    min = arr[i].Length;

            }
            return min;
        }
        public static int SearchInsert(int[] nums, int target)
        {
            var result = 0;

            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == target)
                {
                    result = i;
                }
                else if (nums[i] < target)
                {
                    result = i + 1;
                }

            }

            return result;
        }
        public static int FindDuplicates(int[] nums)
        {
            //int[] temp;
            if (nums.Length == 0) return 0;

            int j = 0;

            for (int i = 1; i < nums.Length; i++)
            {
                if (nums[i] == nums[j])
                {
                    j++;
                    nums[j] = nums[i];
                    break;
                    
                }
            }
            return nums[j];
        }
        public static int RemoveDuplicates(int[] nums)
        {

            if (nums.Length == 0) return 0;

            int j = 0;

            for (int i = 1; i < nums.Length; i++)
            {
                if (nums[i] != nums[j])
                {
                    j++;
                    nums[j] = nums[i];
                }
            }
            return j + 1;
        }
        public static int RemoveElement(int[] nums, int val)
        {

            int j = 0;
            int l = nums.Length;
            while (j < l)
            {
                if (nums[j] == val)
                {
                    nums[j] = nums[l - 1];
                    l--;
                }
                else { j++; }
            }
            //    for (int i = 0; i < nums.Length; i++)
            //    {
            //        if (nums[i] != val)
            //        {
            //        nums[j] = nums[i];
            //        j++;
            //        }
            //    }

            return l;
        }

        public static ListNode MergeTwoLists(ListNode l1, ListNode l2)
        {
            if (l1 == null) return l2; if (l2 == null) return l1;
            if (l2.val > l1.val)
            {
                l1.next = MergeTwoLists(l1.next, l2);
                return l1;
            }
            else
            {
                l2.next = MergeTwoLists(l1, l2.next);
                return l2;

            }

        }
        public static ListNode AddTwoNumbers(ListNode l1, ListNode l2)
        {
            ListNode dummyhead = new ListNode(0);
            int carry = 0;
            ListNode p = l1, q = l2, curr = dummyhead;
            while (p != null || q != null)
            {
                int x = (p != null) ? p.val : 0;
                int y = (q != null) ? q.val : 0;
                int sum = carry + x + y;
                carry = sum / 10;
                curr.next = new ListNode(sum % 10);
                curr = curr.next;
                if (p != null) p = p.next;
                if (q != null) q = q.next;
            }
            if (carry > 0)
            {
                curr.next = new ListNode(carry);
            }

            return dummyhead.next;
        }
        public static int LengthOfLongestSubstring(string s)
        {
            StringBuilder dummy = new StringBuilder();
            int prevIndex, cur_length = 1, max_len = 1;
            int[] temp = new int[256];
            if (s.Length == 0) return s.Length;
            for (int i = 0; i < temp.Length; i++)
            {
                temp[i] = -1;
            }
            temp[s[0]] = 0;
            dummy.Append(s[0]);
            for (int j = 1; j < s.Length; j++)
            {
                //index of previous charector
                prevIndex = temp[s[j]];
                //       //* If the current character is not present in
                //the already processed substring or it is not
                //    part of the current NRCS, then do cur_len++ *
                if (prevIndex == -1 || j - cur_length > prevIndex)
                {
                    cur_length++;
                    dummy.Append(s[j]);
                }
                else
                {
                    if (cur_length > max_len)
                    {
                        max_len = cur_length;
                    }
                    dummy.Remove(prevIndex, (dummy.Length - (j - prevIndex)));
                    cur_length = j - prevIndex;
                }
                //update the index of cureent charector
                temp[s[j]] = j;

            }

            if (cur_length > max_len)
            {

                max_len = cur_length;
            }



            return max_len;
        }
        
        public static int StrStr(string haystack, string needle)
        {
            // if ((haystack.Length == 0 && needle.Length == 0) || needle.Length == 0) return 0;
            // if (haystack.Length == 1 && needle.Length == 1 && haystack == needle) return 0;

            for (var i = 0; i < haystack.Length; i++)
            {
                for (int j = 0; j < needle.Length; j++)
                {
                    if (j == needle.Length) return i;

                    //if (i + j == haystack.Length) return -1;
                    //if (needle[j] != haystack[i + j]) break;
                    if ((haystack.Length - i >= needle.Length) && haystack.Substring(i, needle.Length) == needle)
                    {
                        return i;

                    }
                    else break;



                }
            }


            return -1;
        }
        public static bool GetCurrentQuarter()
        {
            DateTime dt = DateTime.UtcNow.Date;

            DateTime prevDt = DateTime.ParseExact("Jan", "MMM", CultureInfo.InvariantCulture); //
            int quarter = (DateTime.Now.Month + 2) / 3;
            if (quarter != (int)Math.Ceiling(((double)prevDt.AddMonths(-3).Month) / (double)3))
            {
                return true;
            }
            else { return false; }


        }
        public static int GetSmallest(int[] nums)
        {
            Array.Sort(nums);

            for (var i = 1; i < nums.Count(); i++)
            {
                if (nums[i] != nums[i - 1] + 1 && nums[i] != nums[i - 1])
                {
                    if (nums[i] > -1)
                        return nums[i - 1] + 1;
                    else
                        return 1;

                }
                else if (nums[i] == nums[i - 1] + 1 && i == nums.Count() - 1)
                {
                    return nums[i] + 1;
                }


            }
            return 0;

        }
        public static double FindMedianSortedArrays(int[] nums1, int[] nums2)
        {

            int[] temp = nums2.Concat(nums1).OrderBy(x => x).ToArray();
            var last = temp.Count();
            var mid = (0 + last) / 2;
            var medean = 0;

            for (var i = 0; i < temp.Count(); i++)
            {
                if (i == mid && temp.Count() % 2 != 0)
                {
                    medean = temp[i] / temp.Count();
                }
                else if (i == mid || i == mid + 1 && temp.Count() % 2 == 0)
                {
                    var val = +temp[i];
                    medean = val / temp.Count();

                }

            }
            return medean;
        }



        public static IEnumerable<List<Login>> GetTestLoginData()
        {
            using (var csv = new CsvReader(new StreamReader(@"c:\Users\gayathrim\Documents\Visual Studio 2015\Projects\SeleniumTest1\SeleniumTest1\Login.csv"), true))
            {
                while (csv.ReadNextRecord())
                {
                    int fieldCount = csv.FieldCount;
                    string[] headers = csv.GetFieldHeaders();
                    List<Login> login = new List<Login>();
                    Login l = new Login();
                    for (int i = 0; i < fieldCount; i++)
                    {
                        string[] values = null;
                        values = csv[i].Split('\t');
                        l.company = values[0];
                        l.id = values[1];
                        l.pin = values[2];
                    }
                    login.Add(l);
                    yield return login;//new[] { company, id, pin };
                }

            }
        }
        public static bool BackspaceCompare(string S, string T)
        {
            var val = false;
            var match1 = string.Empty;
            var match2 = string.Empty;

            if (S.Length == 0 && S.Length > 200)
            {
                return false;
            }
            else if (T.Length == 0 && T.Length > 200)
            {
                return false;
            }

            for (var sr = 0; sr < S.Length; sr++)
            {
                if (S[sr].ToString() != "#")
                {
                    match1 += S[sr];

                }
                else if (match1.Length >= 1)
                {
                    match1 = match1.Remove(match1.LastIndexOf(match1.Last()));
                }


            }

            for (var tr = 0; tr < T.Length; tr++)
            {
                if (T[tr].ToString() != "#")
                {
                    match2 += T[tr];
                }
                else if (match2.Length >= 1)
                {
                    match2 = match2.Remove(match2.LastIndexOf(match2.Last()));

                }

            }
            if (match1.Equals(match2))
            {
                return true;
            }


            return val;
        }

        public static int BinarySearch(string s, string key)
        {
            int low = 0;
            int high = s.Length - 1;
            int mid = (low + high) / 2;
            while (low <= high)
            {
                if (s[mid].Equals(key) && s[low] < s[mid])
                {
                    low = mid + 1;
                }
                else if (s[mid] > s[mid] && s[low].Equals(key))
                {
                    high = mid - 1;
                }
                else
                {
                    return mid;
                }

            }
            return -1;
        }
        public static List<int>  SwapNum(int i, int j)
        {
            var results = new List<int>();
            results.Add(j);
            results.Add(i);
            return results.ToList();
        }
        public static string GetSpecifiedChars(string s)
        {
            var temp = string.Empty;
            if(s!=null && s.Length ==1)
            { return s; }
            else if(String.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            int count = 0;
            while (count < 2)
            {
                
                temp += s[count];
                count++;
            }
            return temp;
        }
        public static void PrintTraingle(int num, int width)
        {
            int height = width;
           for(int i =0; i < height; i++)
            {
                for(int j=0;j <width; j++)
                {
                    Console.Write(num);
                }
                Console.WriteLine();
                width--;
            }
        }
    }
    public static class MyBigInteger
    {
        public static int BitLength(this BigInteger n)
        {
            byte[] Data = n.ToByteArray();
            int result = (Data.Length - 1) * 8;
            byte Msb = Data[Data.Length - 1];
            while (Msb != 0)
            {
                result += 1;
                Msb >>= 1;
            }
            return result;
        }
    }
    public class Login
    {
        public string company { set; get; }
        public string id { set; get; }
        public string pin { set; get; }


    }
    public class Solution
    {
        public static bool BackspaceCompare(string S, string T)
        {
            var val = false;
            var match1 = false;
            var match2 = false;
            if (S.Length == 0 && S.Length > 200)
            {
                return false;
            }
            else if (T.Length == 0 && T.Length > 200)
            {
                return false;
            }
            for (var sr = 0; sr < S.Length; sr++)
            {
                if (S[sr].Equals("#"))
                {
                    match1 = true;
                    break;
                }
            }
            for (var tr = 0; tr < T.Length; tr++)
            {
                if (T[tr].Equals("#"))
                {
                    match2 = true;
                    break;
                }

            }
            if (match1 && match2)
            {
                return true;
            }


            return val;
        }
    }
}
